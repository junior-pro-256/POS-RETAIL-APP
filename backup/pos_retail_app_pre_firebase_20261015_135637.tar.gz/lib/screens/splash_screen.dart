import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../routes.dart';
import '../services/app_state.dart';
import '../widgets/common.dart';

/// Screen 1 - Splash / Welcome
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const Spacer(flex: 3),
              Icon(Icons.shopping_cart, size: 96, color: primary),
              const SizedBox(height: 16),
              const Text('POS Retail Pro',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text('Manage your business\nanytime, anywhere',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
              const Spacer(flex: 4),
              PrimaryButton(
                label: 'Get Started',
                onPressed: () {
                  final loggedIn = context.read<AppState>().loggedIn;
                  Navigator.pushReplacementNamed(
                      context, loggedIn ? Routes.home : Routes.login);
                },
              ),
              const SizedBox(height: 20),
              Text('Version 1.0.0',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500)),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
